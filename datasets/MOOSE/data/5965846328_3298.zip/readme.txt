The license to use this dataset can be found here: https://creativecommons.org/licenses/by/4.0/
By using this dataset, you accept by default its license and agree to abide by its terms provided that you do not alter the information contained therein, that their meaning is not distorted.
Please note that this data is transmitted to you as is, without any express or tacit guarantee as to their suitability for a particular purpose or use.

USE: https://creativecommons.org/licenses/by/4.0/
Downloaded from https://campagnes.flotteoceanographique.fr/

Associated DOI:
 - https://doi.org/10.17600/18001608
